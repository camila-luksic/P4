public class Piezas {
    private static Logger logger = LogManager.getRootLogger();
}
