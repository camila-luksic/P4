import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.awt.*;
import java.lang.reflect.Array;
import java.util.Iterator;
import java.util.Random;

public class Piezas <E>implements Iterable<E> {
    private static Logger logger = LogManager.getRootLogger();

    int width=800;
    int height=400;
    public int x;
    public int y;
    public int estado;

    public int tamano=20;

    private Nodo <E> raiz;
    public Piezas(){
        raiz=null;
        this.x=x;
        this.y=y;
        this.estado=estado;

    }

    public int getX() {

        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public int getTamano() {
        return tamano;
    }

    public void setTamano(int tamano) {
        this.tamano = tamano;
    }


    public boolean contiene(int x, int y) {
        if (x < (this.x + this.tamano) &&
                x > (this.x) &&
                y < (this.y + this.tamano) &&
                y > (this.y)) {
            return true;
        }
        return false;
    }

    public void matar() {
        estado = 0;
    }



    enum EstadoPieza { viva, herida,debil,muerta}
    public void insertar(E o){
        Nodo<E> nuevo=new Nodo<> (o);
        nuevo.setSiguiente(raiz);
        raiz=nuevo;
        nuevo.setContenido(x,y);
        logger.info("Agrego las 7 piezas a cada lado");
        paint();
    }
/*

    public boolean matoPieza(int x, int y) {
        int vida = 3;
        for (int i = 0; i < 7; i++) {
            if (piezas[i].contiene(x, y)) {
                vida--;
                pieza.cambiarColor();
                if (vida == 0) {
                    piezas[i].matar();
                    return true;
                }
            }
            return false;
        }
    }

        public void cambiarColor (Graphics) {
        if (vida == 2) {
            setColor(Color.blue);
        }
        if (vida == 1) {
                .setColor(Color.cyan);
        }
        }

 */
        public void paint(Graphics g){
        Random random = new Random(1234);
        int mita = width / 2;
        for (int i = 0; i < 7; i++) {
            int x1 = random.nextInt(mita);
            int y1 = random.nextInt(height);
            g.setColor(Color.BLUE);
            g.fillOval(x1, y1, tamano, tamano);


        }
        for (int i = 0; i < 7; i++) {
            int x2 = random.nextInt(mita) + mita;
            int y2 = random.nextInt(height);
            g.setColor(Color.RED);
            g.fillOval(x2, y2, tamano, tamano);

        }
    }
        public void agregar (E o){
            if (raiz == null) {
                insertar(o);
                return;
            }
            Nodo<E> actual = raiz;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            Nodo<E> nuevo = new Nodo<>(o);
            actual.setSiguiente(nuevo);
            logger.info("Agrego una sola pieza a cada lado");
            paint1();
        }

        private void paint1 () {
            Graphics g = null;
            Random random = new Random(1234);
            int mita = width / 2;
            for (int i = 0; i < 1; i++) {
                int x12= random.nextInt(mita);
                int y12 = random.nextInt(height);
                g.setColor(Color.BLUE);
                g.fillOval(x12, y12, 20, 20);


            }
            for (int i = 0; i < 1; i++) {
                int x21 = random.nextInt(mita) + mita;
                int y21 = random.nextInt(height);
                g.setColor(Color.RED);
                g.fillOval(x21, y21, 20, 20);

            }
        }

        public String toString () {
            StringBuilder resultado = new StringBuilder();
            Nodo<E> actual = raiz;
            while (actual != null) {
                resultado.append(actual).append(" --> ");
                actual = actual.getSiguiente();
            }
            return resultado.toString();
        }



    @Override
    public Iterator <E> iterator() {
        return new PiezasIterator<>(raiz) {
        };
    }


    class Nodo<E> {
        private E contenido;
        private Nodo<E> siguiente;
        public Nodo(E o){
            siguiente=null;
            contenido=o;

        }

        public Nodo<E> getSiguiente(){
            return siguiente;
        }

        public void setSiguiente(Nodo<E> siguiente) {
            this.siguiente=siguiente;
        }

        public E getContenido() {
            return contenido;
        }

        public void setContenido(E contenido) {
            this.contenido = contenido;
        }
        public String toString() {
            return contenido.toString();
        }

        public void setContenido(int x, int y) {

        }
    }

    class PiezasIterator<E> implements Iterator<E> {
        private Nodo<E> actual;

        public PiezasIterator(Nodo<E> r) {
            actual = r;
        }

        public boolean hasNext() {
            return actual != null;
        }

        public E next() {
            E obj = actual.getContenido();
            actual = actual.getSiguiente();
            return obj;
        }

    }
}

