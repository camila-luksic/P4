import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.awt.*;

public class Jugador {
    private static Logger logger = LogManager.getRootLogger();

    public Jugador(Color red) {
    }



