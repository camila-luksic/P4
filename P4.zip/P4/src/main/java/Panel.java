import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.swing.*;

public class Panel extends JPanel {
    private static Logger logger = LogManager.getRootLogger();
}
