import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class Main {
    private static Logger logger = LogManager.getRootLogger();
    public static void main(String[] args) {
     new Frame();
    }
}
