import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.swing.*;

public class Frame extends JFrame {
    private static Logger logger = LogManager.getRootLogger();

}
